﻿namespace StudentManagementSystem.Models
{
    public class StudentViewModel
    {
        public int StudentId { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public string LecturerName { get; set; }
    }
}
