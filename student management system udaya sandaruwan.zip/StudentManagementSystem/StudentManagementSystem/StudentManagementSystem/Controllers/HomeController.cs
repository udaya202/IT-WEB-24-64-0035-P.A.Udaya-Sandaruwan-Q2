using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using StudentManagementSystem.Models;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient; 
using Dapper;
using StudentManagementSystem.Models;  
using System.Linq;

namespace StudentManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly string connectionString = "Data Source=OGOTECHNOLOGY;Initial Catalog=StudentManagementDB;Integrated Security=True;Trust Server Certificate=True";

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddStudent()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                var courses = conn.Query<Course>("SELECT * FROM Courses").ToList();
                return View(courses);
            }
        }

        [HttpPost]
        public IActionResult AddStudent(Student student)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string sql = "INSERT INTO Students VALUES (@StudentId, @Name, @City, @CourseID)";
                conn.Execute(sql, student);
                return RedirectToAction("StudentInformation");
            }
        }

        public IActionResult AddCourse()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddCourse(Course course)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string sql = "INSERT INTO Courses VALUES (@CourseId, @Name, @LecturerName)";
                conn.Execute(sql, course);
                return RedirectToAction("StudentInformation");
            }
        }

        public IActionResult StudentInformation()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string sql = @"SELECT s.*, c.Name as CourseName, c.LecturerName 
                          FROM Students s 
                          JOIN Courses c ON s.CourseID = c.CourseId";
                var students = conn.Query<StudentViewModel>(sql).ToList();
                return View(students);
            }
        }
    }
}
